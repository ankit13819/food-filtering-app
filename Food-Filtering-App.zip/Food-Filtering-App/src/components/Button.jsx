import React from "react";
import Data from "./Data";
const Buttons = ({ menuItems, filterItem, setItem }) => {
  return (
    <React.Fragment>
      <div className="d-flex justify-content-center">
        {menuItems.map((Val, id) => {
          return (
            <button
              className="btn-dark text-white p-1 px-2 mx-5 btn fw-bold"
              key={Val.id}
              onClick={() => filterItem(Val)}
            >
              {Val}
            </button>
          );
        })}
        <button
          className="btn-dark text-white p-1 mx-5 fw-bold btn"
          onClick={() => setItem(Data)}
        >
          All
        </button>
      </div>
    </React.Fragment>
  );
};
export default Buttons;
