import React, { useState } from "react";
import Card from "./components/Card";
import Data from "./components/Data";
import Buttons from "./components/Button";
function App() {
  const [item, setItem] = useState(Data);

  const menuItems = [...new Set(Data.map((Val) => Val.category))];

  const filterItem = (curcat) => {
    const newItem = Data.filter((newVal) => {
      return newVal.category === curcat;
    });
    setItem(newItem);
  };

  return (
    <React.Fragment>
      <div className="container-fluid">
        <h1 className="col-12 text-center my-3 fw-bold">Food Filtering App</h1>
        <Buttons
          menuItems={menuItems}
          filterItem={filterItem}
          setItem={setItem}
        />
        <Card data={item} />
      </div>
    </React.Fragment>
  );
}

export default App;
